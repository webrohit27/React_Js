import React from "react";
// import Login from "./Login";
import "../css/home.css";

const Home = () => {
  return (
    <div className="container mt-3 py-5 d-flex justify-content-evenly align-content-center flex-wrap" >
      {/* <div className="login-container" >
        <Login/>
        </div> */}
      {/* <div className="login-img" ></div> */}

    </div>
  );
};

export default Home;
