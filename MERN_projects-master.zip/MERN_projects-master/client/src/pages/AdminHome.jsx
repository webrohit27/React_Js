import React from 'react'

const AdminHome = () => {
  return (
    <div>
      <h1>AdminHome</h1>
    </div>
  )
}

export default AdminHome
